<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	
	public function index()
	{
		//echo "string";
		$this->load->view('admin/index');
	}
	public function login()
	{
		//echo "login";
		$this->load->view('admin/login');
	}
	public function logout()
	{
		$this->session->unset_userdata('status');
		$this->session->session_destroy();
		redirect(base_url());
	}
	public function register()
	{
		//echo "login";
		$this->load->view('admin/register');
	}
	function register_action()
	{
		echo "<pre>";
			print_r($_POST);
				echo "</pre>";

		echo "<pre>";
			print_r($_FILES);
				echo "</pre>";


	}
	function loginr_action()
	{
		echo "<pre>";
			print_r($_POST);
				echo "</pre>";
	}
}
?>
