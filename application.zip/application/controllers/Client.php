<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client extends CI_Controller {

	
	public function index()
	{
		// echo "TEST";
		// $this->load->model('client_model');
		// $res1 = $this->client_model->get_category();
		// print_r($res1);
		// $this->load->view('index',array("x1"=>$res1));
		$this->load->view('index');
	}
	function filtercat($id){
		$result=$this->myclass->get_products(" and category_id='$id'");
		// echo "<pre>";
		// print_r($ans);
		// echo "<pre>";
		$this->load->view('filter_cat',array("xyz"=>$result));
	}
	function filterbrand($id){
		$result=$this->myclass->get_products(" and category_id='$id'");
		// 	echo "<pre>";
		// print_r($result);
		// echo "<pre>";
	if(is_array($result)):
								foreach($result as $val):
						?>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="<?php echo base_url();?>assets/products/<?php echo $val['path'] ?>" alt="" />
											<h2><?php echo $val['price'] ?></h2>
											<p><?php echo $val['product'] ?></p>
											<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2><?php echo $val['price'] ?></h2>
											<p><?php echo $val['product'] ?></p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to compare</a></li>
									</ul>
								</div>
							</div>
						</div>
						<?php  
							endforeach;
						endif;
					
						

	
	}
}
