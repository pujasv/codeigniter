<?php
	class Myclass{
		public $CI="";
		function __construct(){
			$this->CI =& get_instance();
		}
		function get_category(){
			
			// print_r($this->CI);
			return $this->CI->db->get("category")->result_array();
		}
		function get_brand(){
			return $this->CI->db->get("brand")->result_array();
		}
		function get_products($condition=""){

			// $this->db->select('*');
			// $this->db->from('blogs');
			// $this->db->join('comments', 'comments.id = blogs.id');
			// $query = $this->db->get();
			$sql = "select products.id as pid,products.name as product,price,discount,path,description,category.name as cat,brand.name as br from category,brand,products where brand.id=brand_id and category.id=category_id $condition";
			$ans = $this->CI->db->query($sql);
			// print_r($ans);
		foreach ($ans->result_array() as $row)
			{
			     // print_r($row);
			     // echo "<br />";
				$data[] = $row;
			}

			return $data;
		}
	}
?>