<?php 
  $this->load->view('admin/header');
?>
<div class="container-fluid"> 
	<div class="card card-register mx-auto mt-5">
        <div class="card-header">Category Page</div>
        <div class="card-body">
          <form id="brand_form">
            
            <div class="form-group">
              <div class="form-row">
                <div class="col-md-12">
                  <div class="form-label-group">
                    <input type="text" name="name" id="inputPassword" class="form-control" placeholder="Password" required="required">
                    <label for="inputPassword">Killer Jeans</label>
                  </div>
                </div>
                
              </div>
            </div>
            
            
            
            <button type="button" class="btn btn-primary btn-block btn-brand" >Add</button>
          </form>
          <div class="brand_err">
            
          </div>
        </div>
      </div>
</div>
<?php 
  $this->load->view('admin/footer');
?>       