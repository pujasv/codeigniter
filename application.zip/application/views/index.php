index
<a href="<?php echo base_url('index.php/admin/admin');?>">Admin panel</a>
