<?php  
	class Client_model extends CI_Model{
		

		function get_category(){
			return $this->db->get("category")->result_array();
		}
		function get_brand(){
			return $this->db->get("brand")->result_array();
		}

	}
?>